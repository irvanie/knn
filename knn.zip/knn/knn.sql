-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2021 at 06:59 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `knn`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(20) CHARACTER SET latin1 NOT NULL,
  `password` varchar(32) CHARACTER SET latin1 NOT NULL,
  `nama_lengkap` varchar(30) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`, `nama_lengkap`) VALUES
('admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `data_testing`
--

CREATE TABLE `data_testing` (
  `id` int(100) NOT NULL,
  `nilai_tes_tulis` int(100) NOT NULL,
  `nilai_wawancara` int(100) NOT NULL,
  `nilai_divisi` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `data_testing`
--

INSERT INTO `data_testing` (`id`, `nilai_tes_tulis`, `nilai_wawancara`, `nilai_divisi`) VALUES
(8, 70, 70, 70),
(9, 70, 70, 70);

-- --------------------------------------------------------

--
-- Table structure for table `data_traingema`
--

CREATE TABLE `data_traingema` (
  `id` int(100) NOT NULL,
  `nilai_tes_tulis` int(100) NOT NULL,
  `nilai_wawancara` int(100) NOT NULL,
  `nilai_divisi` int(100) NOT NULL,
  `keterangan` varchar(100) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `data_traingema`
--

INSERT INTO `data_traingema` (`id`, `nilai_tes_tulis`, `nilai_wawancara`, `nilai_divisi`, `keterangan`) VALUES
(2, 90, 80, 85, 'Sesuai Minat'),
(3, 90, 90, 85, 'Sesuai Minat');

-- --------------------------------------------------------

--
-- Table structure for table `data_training`
--

CREATE TABLE `data_training` (
  `id` int(100) NOT NULL,
  `nilai_tes_tulis` int(100) NOT NULL,
  `nilai_wawancara` int(100) NOT NULL,
  `nilai_divisi` int(100) NOT NULL,
  `keterangan` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `data_training`
--

INSERT INTO `data_training` (`id`, `nilai_tes_tulis`, `nilai_wawancara`, `nilai_divisi`, `keterangan`) VALUES
(5, 90, 80, 85, 'Sesuai Minat'),
(6, 60, 70, 75, 'Tidak Sesuai Minat'),
(7, 90, 85, 85, 'Sesuai Minat'),
(8, 70, 70, 65, 'Tidak Sesuai Minat'),
(9, 85, 85, 85, 'Sesuai Minat'),
(10, 90, 90, 90, 'Sesuai Minat'),
(11, 80, 80, 80, 'Sesuai Minat'),
(12, 90, 95, 95, 'Sesuai Minat'),
(13, 100, 50, 60, 'Tidak Sesuai Minat'),
(15, 90, 90, 90, 'Sesuai Minat'),
(16, 75, 75, 75, 'Sesuai Minat'),
(17, 85, 90, 50, 'Tidak Sesuai Minat'),
(18, 50, 50, 50, 'Tidak Sesuai Minat'),
(19, 70, 70, 70, 'Tidak Sesuai Minat'),
(20, 80, 80, 85, 'Sesuai Minat'),
(21, 78, 82, 88, 'Sesuai Minat'),
(22, 83, 80, 81, 'Sesuai Minat'),
(23, 100, 95, 100, 'Sesuai Minat'),
(24, 80, 75, 55, 'Tidak Sesuai Minat'),
(25, 85, 85, 75, 'Sesuai Minat');

-- --------------------------------------------------------

--
-- Table structure for table `data_trainingmpm`
--

CREATE TABLE `data_trainingmpm` (
  `id` int(100) NOT NULL,
  `nilai_tes_tulis` int(100) NOT NULL,
  `nilai_wawancara` int(100) NOT NULL,
  `nilai_divisi` int(100) NOT NULL,
  `keterangan` varchar(100) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `data_trainingmpm`
--

INSERT INTO `data_trainingmpm` (`id`, `nilai_tes_tulis`, `nilai_wawancara`, `nilai_divisi`, `keterangan`) VALUES
(2, 50, 60, 80, 'Tidak Sesuai Minat'),
(3, 90, 80, 85, 'Sesuai Minat'),
(4, 90, 70, 85, 'Sesuai Minat');

-- --------------------------------------------------------

--
-- Table structure for table `data_trainkopma`
--

CREATE TABLE `data_trainkopma` (
  `id` int(100) NOT NULL,
  `nilai_tes_tulis` int(100) NOT NULL,
  `nilai_wawancara` int(100) NOT NULL,
  `nilai_divisi` int(100) NOT NULL,
  `keterangan` varchar(100) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `data_trainkopma`
--

INSERT INTO `data_trainkopma` (`id`, `nilai_tes_tulis`, `nilai_wawancara`, `nilai_divisi`, `keterangan`) VALUES
(5, 90, 80, 85, 'Sesuai Minat'),
(6, 45, 70, 65, 'Tidak Sesuai Minat');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `data_testing`
--
ALTER TABLE `data_testing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_traingema`
--
ALTER TABLE `data_traingema`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_training`
--
ALTER TABLE `data_training`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_trainingmpm`
--
ALTER TABLE `data_trainingmpm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_trainkopma`
--
ALTER TABLE `data_trainkopma`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_testing`
--
ALTER TABLE `data_testing`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `data_traingema`
--
ALTER TABLE `data_traingema`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `data_training`
--
ALTER TABLE `data_training`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `data_trainingmpm`
--
ALTER TABLE `data_trainingmpm`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `data_trainkopma`
--
ALTER TABLE `data_trainkopma`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
