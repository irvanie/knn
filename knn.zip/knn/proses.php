<?php 
include ("koneksi.php");

$testrain = $koneksi->query("SELECT * FROM data_testing");

	

$koneksi->query("CREATE TEMPORARY TABLE RangkingSementara(
        Rangking int AUTO_INCREMENT primary key,
        nama varchar(100),
       	nilai_tes_tulis int,
        nilai_wawancara int,
       	nilai_divisi int,
        nilai int,
        keterangan varchar(100));
    ");

$koneksi->query("CREATE TEMPORARY TABLE Kesimpulan(
        Nomor int AUTO_INCREMENT primary key,
        nama varchar(100),
       	nilai_tes_tulis int,
        nilai_wawancara int,
       	nilai_divisi int,
        nilai int,
        keterangan varchar(100));
    ");

?>
<!DOCTYPE html>	
<html>
<head>
	<title>Hasil Perhitungan</title>
<title>Nilai Hasil Perhitungan Minat UKM</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
	 <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="img/LogoPNJ.jpg" type="logo" sizes="16x16">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

     <!-- Import Font -->
    <link href="https://fonts.googleapis.com/css?family=Viga&display=swap" rel="stylesheet">

    <!-- Eksternal -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body>
		<?php 
            session_start();
            if($_SESSION['status']!="login"){
                header("location:login.php?pesan=belum_login");
            }
        ?>
	<nav class="navbar navbar-expand-lg navbar-light ">
		 	<div class="container">
				<a class="navbar-brand"><img src="img/LogoPNJ.jpg" width="40" > Politeknik Negeri Jakarta</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="container">
					<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<ul class="navbar-nav mr-auto">
						<li class="nav-item" >
								<a class="nav-link" href="tentang.php"> Tentang</a>
							</li>			
							<li class="nav-item dropdown">
					        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					          Pilih Data Training
					        </a>
							<div class="dropdown-menu" aria-labelledby="navbarDropdown">
					    	<a class="dropdown-item active" href="home.php">Data Training HIMATIK</a>
					          <a class="dropdown-item" href="homegema.php">Data Training BO GEMA</a>
					          <a class="dropdown-item" href="homekopma.php">Data Training BO KOPMA</a>
					          <a class="dropdown-item" href="homempm.php">Data Training MPM</a>
					        </div>
					      </li>
							<li class="nav-item">
								<a class="nav-link" href="perhitungan.php">Proses Perhitungan</a>
							</li>
						</ul>
						<div style="color: white;
						padding: 15px 30px 25px 15px;
						float: right;
						font-size: 10px;"> &nbsp; <a href="login/logout.php" class="btn btn-danger square-btn-adjust">Logout</a> 
						</div>
					</div>
				</div>
		  	</div>
		</nav>

	<div class="jumbotron">
		<center>
			<img src="image/logo2.png" img-circle>
        	<h1>Politeknik Negeri Jakarta</h1>	
			<h1 class="display-4">Nilai Hasil Perhitungan</h1>
		</center>
	</div>

	<div class="container">
		<div class="row">
			<div class="col-md-12" style="font-family: 'Viga', sans-serif;">
					<center>
							<h2>Tabel Hasil Perengkingan</h2>
					</center><br>
					<h5>Nilai K: 3</h5><br>
		
					<form method="POST">
					<h5><label for="">Pilih Data Training UKM :</label>
					    <select class="custom-select col-md-3" name="pil_dtraining" id="pil_dtraining">
					    	<option id="" value="" name=""><--Pilih--></option>
					        <option id="himatik" value="himatik" name="himatik">HIMATIK</option>
					        <option value="gema" name="gema">BO GEMA</option>
					        <option value="kopma" name="kopma">BO KOPMA</option>
					        <option value="mpm" name="mpm">MPM</option>
					    </select>		   
						<button type="submit" class="btn btn-primary" name="pilih">Pilih</button>
					</h5>
				</form>
				    <br><br>
				    <div>
				    	<h5 align="center"><?php 

							$tabel="data_training";
							$label="Data Training HIMATIK";

				    		if (isset($_POST["pilih"])) {

									$tabel="";
									$label="";
									$pil=$_POST["pil_dtraining"];

									 if ($pil == 'himatik') {
									 	$label="Data Training HIMATIK";
									 	$tabel="data_training";

									 }elseif($pil == 'gema') {
									 	$label="Data Training BO GEMA";
									 	$tabel="data_traingema";

									 }elseif($pil == 'kopma') {
									 	$label="Data Training BO KOPMA";
									 	$tabel="data_trainkopma";

									 }elseif($pil == 'mpm') {
									 	$label="Data Training MPM";
									 	$tabel="data_trainingmpm";
									 }	
								}

				    	echo "$label" ?></h5>
				    </div> 
					<?php 
						// nilai K
						$nilaik = 3;
						//nilai data testing
						$dtest = $koneksi->query("SELECT(nama) as Xnmts,
												(nilai_tes_tulis) as X1ts, 
												(nilai_wawancara) as X2ts,
												(nilai_divisi) as X3ts
												FROM data_testing "); 
						$ntest = $dtest->fetch_array();

						//nilai data training
						$dtrain = $koneksi->query("SELECT(nama) as Xnmtr,
												(nilai_tes_tulis) as X1tr, 
												(nilai_wawancara) as X2tr,
												(nilai_divisi) as X3tr,
												(keterangan) as ket
												FROM $tabel ");
							echo "
							 
								<table class='table' border='1'>
									<thead class='thead-dark'>
										<tr>
										    <th scope='col'>N0</th>
											<th scope='col'>Nama</th>
										    <th scope='col'>Tes Masuk</th>
										    <th scope='col'>Tes Wawancara</th>
										    <th scope='col'>Tes Divisi</th>
										    <th scope='col'>Keterangan</th>
										</tr>
									</thead>
							";
						$no=1;

							//proses perhitungan data train dengan data tes

						while ($ntrain = $dtrain->fetch_array()) {

						$nilai = sqrt(pow(($ntest['X1ts']-$ntrain['X1tr']), 2) + pow(($ntest['X2ts']-$ntrain['X2tr']), 2) + pow(($ntest['X3ts']-$ntrain['X3tr']), 2));

							

							//simpan rangking
							$koneksi->query("INSERT INTO RangkingSementara (nama,nilai_tes_tulis,nilai_wawancara,nilai_divisi,nilai,keterangan)
     						 VALUES (
							 '".$ntrain['Xnmtr']."',
							 '".$ntrain['X1tr']."',
     						 '".$ntrain['X2tr']."',
     						 '".$ntrain['X3tr']."',
     						 '".$nilai."',
     						 '".$ntrain['ket']."'
     						); ");

						}


							// Urutkan jarak dari yang terkecil
						      $rangking = $koneksi ->query("SELECT * FROM RangkingSementara ORDER BY nilai ASC LIMIT $nilaik");      
						      while ($datas = $rangking->fetch_array()) {

						      // Simpan kesimpulan
						    $koneksi->query("INSERT INTO Kesimpulan (nama,nilai_tes_tulis,nilai_wawancara,nilai_divisi,nilai,keterangan)
						      VALUES (
									'".$datas['nama']."',
									'".$datas['nilai_tes_tulis']."',
						      		'".$datas['nilai_wawancara']."',
									'".$datas['nilai_divisi']."',
						      		'".$datas['nilai']."',
						      		'".$datas['keterangan']."'
						      		); ");
						      // var_dump($datas['keterangan']);


							$data[] = array('nama'=>$datas['nama'],'nilai_tes_tulis'=>$datas['nilai_tes_tulis'],'nilai_wawancara'=>$datas['nilai_wawancara'],'nilai_divisi'=>$datas['nilai_divisi'],'poin'=>$nilai,'keterangan'=>$datas['keterangan']);

						    }

						foreach ($data as $key => $isi) {
							$nama[$key]=$isi['nama'];
							$keterangan[$key]=$isi['keterangan'];
							$poin[$key]=$isi['poin'];
							$nilaitestulis[$key]=$isi['nilai_tes_tulis'];
							$nilaiwawancara[$key]=$isi['nilai_wawancara'];
							$nilaidivisi[$key]=$isi['nilai_divisi'];
						}

						array_multisort($poin,SORT_ASC,$data);
						
						// $status = "Prioritas";
						// $tingkat = 1;

						foreach ($data as $item) { ?>
	
							<tr>
   								<td><?php echo $no ?></td>
   								<td><?php echo $item['nama'] ?></td>
 								<td><?php echo $item['nilai_tes_tulis'] ?></td>
   								<td><?php echo $item['nilai_wawancara'] ?></td>
   								<td><?php echo $item['nilai_divisi'] ?></td>
  								
   								<td><?php echo $item['keterangan'] ?></td>
   							</tr>
						
   						<?php

   							$no++;
   							// $tingkat++;
   							
  						 }

						echo "</table><br>";
						?>

						 <div class="table-responsive">
						  	<center><h3>Kesimpulan Hasil Prediksi</h3></center>
					      
						    <table class="table" border="1">
						      <thead class='thead-dark'>
						        <tr>
								  <th scope="col">Nama Mahasiswa</th>
						          <th scope="col">Nilai Tes Tulis</th>
						          <th scope="col">Nilai Wawancara</th>
						          <th scope="col">Nilai Divisi</th>
						          <th scope="col">Kesimpulan</th>
						        </tr>
						      </thead>

						      <tbody>
						        <?php
						        	
							        $kesimpulan = $koneksi->query("SELECT keterangan, count(keterangan) as jumlah FROM Kesimpulan GROUP BY keterangan ORDER BY jumlah ASC
									 ");

							        while ($data = $kesimpulan->fetch_array()){

										$ket = "";
										if($data['keterangan'] == 'Sesuai Minat')
												 {$ket = "Sesuai Minat";
	
										}else if($data['keterangan'] == 'Tidak Sesuai Minat')
												{$ket = "Tidak Sesuai Minat";
	
										}  
										// var_dump($data['keterangan']);

									}
						         
						        ?>                
						          <tr>
								    <td align="center"><?=$ntest["Xnmts"]?></td>
						            <td align="center"><?=$ntest["X1ts"]?></td>
						            <td align="center"><?=$ntest["X2ts"]?></td>
						            <td align="center"><?=$ntest["X3ts"]?></td>
						            <td>
	              						<?=$ket?>
	              					</td>
						          </tr>                
						      </tbody>
						    </table>
							
 					<a href="hapus_dttesting.php" class="btn btn-danger">Kembali ke Home</a>
 					<a href="perhitungan.php" class="btn btn-success">Lihat Proses Perhitungan</a>
 			</div>
			 
			 <!-- <div class='content'> -->
			 <br>
			<h2 class='text text-primary'> &nbsp;&nbsp;<button id='print' onClick='window.print();' data-toggle='tooltip' data-placement='right' title='Klik tombol ini untuk mencetak kesimpulan'><i class='fa fa-print'></i> Cetak</button> </h2>
				<!-- <hr><table class='table table-bordered table-striped'> 
			<th width=8%></th>
			<th width=10%>Nilai Tes Tulis</th>
			<th>Nilai Wawancara</th>
			<th width=20%>Nilai Divisi</th>
			<th width=20%>Kesimpulan</th> -->
				<!-- </div> -->
			<!-- </div> -->

 		</div>

		 
 	</div>

		<div id="footer" >
		<div class="card">
  			<div class="card-body">
			  <p><b>&copy; 2021 created by: Muhammad Rashad</p>
  			</div>
		</div>
	</div>

	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html> 

