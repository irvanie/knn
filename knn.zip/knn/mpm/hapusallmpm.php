<?php 
include '../koneksi.php';
$ambil=$koneksi->query("SELECT * FROM data_trainingmpm WHERE id='$_GET[id]'");
$pecah=$ambil->fetch_assoc();

$koneksi->query("DELETE FROM data_trainingmpm");

echo "<script>alert('Data Dihapus');</script>";
echo "<script>location='../homempm.php';</script>";

?>