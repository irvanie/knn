<?php include "koneksi.php";
	
?>
<!DOCTYPE html>	
<html lang="en">
<head>
	<title>About</title>
	
	 <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="img/LogoPNJ.jpg" type="logo" sizes="16x16">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

     <!-- Import Font -->
    <link href="https://fonts.googleapis.com/css?family=Viga&display=swap" rel="stylesheet">

    <!-- Eksternal -->
    <link rel="stylesheet" type="text/css" href="style3.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body>
		<?php 
            session_start();
            if($_SESSION['status']!="login"){
                header("location:login.php?pesan=belum_login");
            }
        ?>
		<nav class="navbar navbar-expand-lg navbar-light ">
		 	<div class="container">
				<a class="navbar-brand"><img src="img/LogoPNJ.jpg" width="40"> Politeknik Negeri Jakarta </a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="container">
					<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<ul class="navbar-nav mr-auto">		
						<li class="nav-item" >
								<a class="nav-link" href="tentang.php"> Tentang</a>
							</li>								
							<li class="nav-item dropdown">
					        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					          Pilih Data Training
					        </a>
					        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
					    	<a class="dropdown-item active" href="home.php">Data Training HIMATIK</a>
					          <a class="dropdown-item" href="homegema.php">Data Training BO GEMA</a>
					          <a class="dropdown-item" href="homekopma.php">Data Training BO KOPMA</a>
					          <a class="dropdown-item" href="homempm.php">Data Training MPM</a>
					        </div>
					      </li>
							<li class="nav-item" >
								<a class="nav-link" href="perhitungan.php">Proses Perhitungan</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="proses.php">Hasil Prediksi</a>
							</li>
						</ul>
						<div style="color: white;
						padding: 15px 30px 25px 15px;
						float: right;
						font-size: 10px;"> &nbsp; <a href="login.php" class="btn btn-danger square-btn-adjust">Logout</a> 
						</div>
					</div>
				</div>
		  	</div>
		</nav>

	<div class="jumbotron">
		<center>
			<img src="img/LogoPNJ2.png" img-circle width="200" >
        	<h1 class="p">Data Mining</h1>	
			<h2>Perhitungan KNN Untuk menentukan pola minat UKM Mahasiswa</h2>
		</center>
	</div>

	<div class="container">
		<div class="row">
			<div class="col-md-12" style="font-family: 'Viga', sans-serif;">
				<center>
						<h2 style="font-family: 'Viga', sans-serif;">About</h2>
				<br><br>

				<div class="container">
				<form method="row">
					<div class="ma3">
  					<article class="tc w-75 center pt5 pb2 ph3 mw6-ns ba bw1 b--light-gray" style="background: #fff;">
   					 <header class="mb4">
	
						<img class="br-100" src="img/rashad.jpg" alt="Profile headshot" />
    				  	<h1 class="f3 lh-title mv2 dark-gray">Politeknik Negeri Jakarta</h1>
				  		<p class="f6 silver mt2 mb0"><a class="link dim silver"><button style="margin-bottom: 10px;" type="button" class="btn btn-secondary" data-toggle="tooltip" data-placement="bottom" title="Pengembang Aplikasi"><i class="fa fa-user" aria-hidden="true"></i> Muhammad Rashad </button></a>
					<a class="link dim silver"><button style="margin-bottom: 10px;" type="button" class="btn btn-secondary" data-toggle="tooltip" data-placement="bottom" title="Dosen Pembimbing"><i class="fa fa-user-md" aria-hidden="true"></i> 	Asep Taufik Muharram , S.Kom., M.Kom. </button></a>
					<br>
					<h2 class="f5 silver mt2 mb1">K-Nearest Neighbour, Prediksi Minat UKM Politeknik Negeri Jakarta</h2>
					<h2 class="f5 silver mt2 mb1">Copyright © 2021, <a class="link dim silver">Politeknik Negeri Jakarta</a></h2>
					<br>
					<a class="link dim light-silver"  style="font-size: 40px;"><i class="fa fa-chrome" aria-hidden="true"></i></a>
					<a class="link dim light-silver"  style="font-size: 40px;"><i class="fa fa-firefox" aria-hidden="true"></i></a>
					<a class="link dim light-silver"  style="font-size: 40px;"><i class="fa fa-edge" aria-hidden="true"></i></a>
					<a class="link dim light-silver"  style="font-size: 40px;"><i class="fa fa-safari" aria-hidden="true"></i></a>
					<a class="link dim light-silver"  style="font-size: 40px;"> | </a>
					<a class="link dim light-silver"  style="font-size: 40px;"> 	<img src="img/LogoPNJ3.png" alt="Profile headshot" /></a>
					</header>
					<p class="f6 tl lh-copy silver" style="margin: 20px;">Sistem Implementasi K-NN yang mampu memprediksi minat Mahasiswa terhadap UKM HIMATIK, BO GEMA, BO KOPMA, dan MPM di Politeknik Negeri Jakarta.</p>
				</article>
				<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
				<ol class="carousel-indicators">
					<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
					<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
					<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
				</ol>
				<div class="carousel-inner">
					<div class="carousel-item active">
					<img class="d-block w-50" src="img/himatik.png" width="10" alt="First slide">
					</div>
					<div class="carousel-item">
					<img class="d-block w-50" src="img/gema1.png" alt="Second slide">
					</div>
					<div class="carousel-item">
					<img class="d-block w-50" src="img/kopma.jpg" alt="Third slide">
					</div>
					<div class="carousel-item">
					<img class="d-block w-50" src="img/mpm1.png" alt="fourth slide">
					</div>
				</div>
				<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>
				<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				</a>
				</div>

				</form>
				</div>				
			</div>
		</div>
	</div>

	<div id="footer" >
		<div class="card">
  			<div class="card-body">
    			<p><b>&copy; 2021 created by: Muhammad Rashad</p>
  			</div>
		</div>
	</div>
	
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>