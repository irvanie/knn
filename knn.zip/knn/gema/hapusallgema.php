<?php 
include '../koneksi.php';
$ambil=$koneksi->query("SELECT * FROM data_traingema WHERE id='$_GET[id]'");
$pecah=$ambil->fetch_assoc();

$koneksi->query("DELETE FROM data_traingema");

echo "<script>alert('Data Dihapus');</script>";
echo "<script>location='../homegema.php';</script>";

?>